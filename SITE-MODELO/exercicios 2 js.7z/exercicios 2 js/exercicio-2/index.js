function iniciarFunction(){

    let number = Number(window.prompt("Digite um número: "));

    if(number % 2 == 0){
        window.alert(`o número ${number} é par.`);
    }else{
        window.alert(`o número ${number} é ímpar.`);
    }
}