function ShowDateTime() {

    let date = new Date();

    let day = date.getDate();
    let month = date.getMonth() + 1;
    let week = date.getDay();
    let hour = date.getHours();
    let minute = date.getMinutes();
    let second = date.getSeconds();

    let message = "data:" + day + ":" + month + "\n" +
        "semana: " + week + "\n" +
        "hora: " + hour + ":" + minute + ":" + second;

    alert(message);
}
