function verifyIdade(){

    let idade = Number(window.prompt("Qual sua idade"));



    if(idade >= 18){
        alert('Você é maior de idade, compra válida')
    }else {
        alert('Você é menor de idade, compra inválida')
    }
    
}